const fs = require('fs');
const path = require('path');

const imgDir = path.join(__dirname, '../public/Images');
if (!fs.existsSync(imgDir)) {
  fs.mkdirSync(imgDir, { recursive: true });
}

const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#061224"/>
      <stop offset="50%" stop-color="#0f2b54"/>
      <stop offset="100%" stop-color="#040b17"/>
    </linearGradient>
    <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#d4af37"/>
      <stop offset="50%" stop-color="#fff2a8"/>
      <stop offset="100%" stop-color="#aa7c11"/>
    </linearGradient>
    <linearGradient id="blueGlow" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#00a2ff"/>
      <stop offset="100%" stop-color="#0033aa"/>
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="8" result="blur"/>
      <feMerge>
        <feMergeNode in="blur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>

  <!-- Deep Blue Stage Background -->
  <rect width="1920" height="1080" fill="url(#bg)"/>

  <!-- Geometric Stage Lines -->
  <circle cx="960" cy="540" r="500" fill="none" stroke="#0066cc" stroke-width="1.5" opacity="0.25"/>
  <circle cx="960" cy="540" r="380" fill="none" stroke="url(#gold)" stroke-width="2" opacity="0.35"/>
  <line x1="0" y1="540" x2="1920" y2="540" stroke="#0088ff" stroke-width="1" opacity="0.15"/>
  <line x1="960" y1="0" x2="960" y2="1080" stroke="#0088ff" stroke-width="1" opacity="0.15"/>

  <!-- Stage Spotlights -->
  <polygon points="200,0 400,0 800,1080 100,1080" fill="#00a2ff" opacity="0.04"/>
  <polygon points="1720,0 1520,0 1120,1080 1820,1080" fill="#00a2ff" opacity="0.04"/>

  <!-- Outer Frame -->
  <rect x="20" y="20" width="1880" height="1040" rx="12" fill="none" stroke="url(#gold)" stroke-width="3" opacity="0.8"/>
  <rect x="32" y="32" width="1856" height="1016" rx="8" fill="none" stroke="#0088ff" stroke-width="1.5" opacity="0.5"/>

  <!-- Header Banner -->
  <polygon points="740,20 1180,20 1140,85 780,85" fill="#0a1d38" stroke="url(#gold)" stroke-width="2"/>
  <text x="960" y="62" font-family="'Arial', 'Helvetica', sans-serif" font-weight="900" font-size="34" fill="#ffe066" text-anchor="middle" filter="url(#glow)">PHẦN THI XUẤT PHÁT</text>

  <!-- Candidate Box 1 Frame (X=14.1%: 270.72px, Y=68.08889%: 735.36px, W=12.45%: 239.04px, H=6.22222%: 67.2px) -->
  <rect x="270.72" y="735.36" width="239.04" height="67.2" rx="6" fill="#0a1b36" stroke="url(#gold)" stroke-width="2.5"/>
  <rect x="273.72" y="738.36" width="233.04" height="61.2" rx="4" fill="url(#blueGlow)" opacity="0.25"/>

  <!-- Other Candidates Frames Placeholder Light Shadows -->
  <rect x="680" y="735.36" width="239.04" height="67.2" rx="6" fill="#0a1b36" stroke="#0066cc" stroke-width="1.5" opacity="0.6"/>
  <rect x="1090" y="735.36" width="239.04" height="67.2" rx="6" fill="#0a1b36" stroke="#0066cc" stroke-width="1.5" opacity="0.6"/>
  <rect x="1500" y="735.36" width="239.04" height="67.2" rx="6" fill="#0a1b36" stroke="#0066cc" stroke-width="1.5" opacity="0.6"/>
</svg>`;

fs.writeFileSync(path.join(imgDir, 'KhoiDongBg.svg'), svgContent, 'utf8');
fs.writeFileSync(path.join(imgDir, 'KhoiDongBg.png'), svgContent, 'utf8');

console.log('Successfully generated KhoiDongBg.svg and KhoiDongBg.png!');
